# Bootstrap 3 Quick Table - CKEditor 4

This plugin is kind of copy paste from https://github.com/ufdada/quicktable with some additions and changes.

Its mean't to add Bootstrap 3 classes to quicktable.

Dependencies: bt_table, panelbutton, floatpanel

Download:

bt_table from https://github.com/kaido24/bt_table

panelbuttons: http://ckeditor.com/addon/panelbutton

Demo: https://www.youtube.com/watch?v=ULDeTUs-xHE


##Other Bootstrap 3 software for CKEditor

Bootstrap 3 Quicktable https://github.com/kaido24/bt_table

Bootstrap 3 grid https://github.com/kaido24/btgrid
