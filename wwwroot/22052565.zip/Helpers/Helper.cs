using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MPLContractIM.Helpers
{
    public static class Helper
    {
        public static DateTime ToDate(string date="",string format="", string lang="en")
        {            
            if(lang == "en") lang = "en-US";
            if(lang == "th") lang = "th-TH";
            if(format == "") {
                format = $"dd-MM-yyyy";
            }
            IFormatProvider culture = System.Globalization.CultureInfo.CreateSpecificCulture(lang);
            return DateTime.ParseExact(date, format, culture);
        }

        public static DateTime ToDateTime(string date="", string format="", string lang="en")
        {            
            if(lang == "en") lang = "en-US";
            if(lang == "th") lang = "th-TH";
            if(format == "") {
                format = $"dd-MM-yyyy hh:mm";
            }
            IFormatProvider culture = System.Globalization.CultureInfo.CreateSpecificCulture(lang);
            return DateTime.ParseExact(date, format, culture);
        }

        public static string ToDateString(DateTime date, string lang="en-US", string connector="-", string format="")
        {
            try
            {
                if(lang == "en") lang = "en-US";
                if(lang == "th") lang = "th-TH";
                if(format == "") {
                    format = $"dd{connector}MM{connector}yyyy";
                }
                IFormatProvider culture = System.Globalization.CultureInfo.CreateSpecificCulture(lang);
                return date.ToString(format, culture);
            }
            catch (System.Exception)
            {
                return "";
            }
        }

        public static string ToDateTimeString(DateTime date, string lang="en-US", string connector="-", string format="")
        {            
            try
            {
               if(lang == "en") lang = "en-US";
                if(lang == "th") lang = "th-TH";
                if(format == "") {
                    format = $"dd{connector}MM{connector}yyyy hh:mm";
                }
                IFormatProvider culture = System.Globalization.CultureInfo.CreateSpecificCulture(lang);
                return date.ToString(format, culture); 
            }
            catch (System.Exception)
            {
                return "";
                throw;
            }
            
        }
    }
}