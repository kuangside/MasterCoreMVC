using System.Collections.Generic;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MPLContractIM.Models
{
    [Table("tboth_request")]
    public class tboth_request
    {
        [Key]
        public int id { get; set; }
        public int mas_id { get; set; }
        public int run_no_id { get; set; }
        [MaxLength(50)]
        public string run_topic { get; set; }
        [MaxLength(50)]
        public string run_no { get; set; }
        [MaxLength(50)]
        public string doc_no { get; set; }
        [MaxLength(50)]
        public string type_request { get; set; }
        [MaxLength(50)]
        public string pic_form { get; set; }
        [MaxLength(50)]
        public string pic_to { get; set; }
        [MaxLength(50)]
        public string date_form { get; set; }
        [MaxLength(50)]
        public string date_to { get; set; }
        [MaxLength(50)]
        public string last_status { get; set; }
        [MaxLength(50)]
        public string input_user { get; set; }
        public DateTime? input_date { get; set; }
        [MaxLength(50)]
        public string req_user { get; set; }
        [MaxLength(100)]
        public string req_name { get; set; }
        [MaxLength(50)]
        public string req_div { get; set; }
        [MaxLength(50)]
        public string req_dept { get; set; }
        [MaxLength(50)]
        public string req_position { get; set; }
        [MaxLength(50)]
        public string req_ext { get; set; }
        [MaxLength(50)]
        public string req_email { get; set; }
        [MaxLength(50)]
        public string mgr_status { get; set; }
        [MaxLength(50)]
        public string mgr_name { get; set; }
        public DateTime? mgr_date {get; set;}
        [MaxLength(250)]
        public string mgr_reason { get; set; }
        [MaxLength(50)]
        public string chk_status { get; set; }
        [MaxLength(50)]
        public string chk_name { get; set; }
        public DateTime? chk_date {get; set;}
        [MaxLength(250)]
        public string chk_reason { get; set; }
        [MaxLength(50)]
        public string cpd_status { get; set; }
        [MaxLength(50)]
        public string cpd_name { get; set; }
        public DateTime? cpd_date {get; set;}
        [MaxLength(250)]
        public string cpd_reason { get; set; }
        [MaxLength(50)]
        public string pre_status { get; set; }
        [MaxLength(50)]
        public string pre_name { get; set; }
        public DateTime? pre_date {get; set;}
        [MaxLength(250)]
        public string pre_reason { get; set; }
        [MaxLength(50)]
        public string akg_status { get; set; }
        [MaxLength(50)]
        public string akg_name { get; set; }
        public DateTime? akg_date {get; set;}
        [MaxLength(250)]
        public string akg_reason { get; set; }
        [MaxLength(50)]
        public string return_status { get; set; }
        [MaxLength(50)]
        public string return_name { get; set; }
        public DateTime? return_date {get; set;}
        [MaxLength(250)]
        public string return_reason { get; set; }

        public virtual tbdoc_process tbdoc_process { get; set; }



        public virtual Dictionary<string, string> type_request_list {
            get {
                var data = new Dictionary<string, string>();
                data.Add("UseOrigin", "Use Origin");
                data.Add("CopyCon", "Copy Contract");
                data.Add("ChangePIC", "Change PIC");
                data.Add("CancelDoc", "Cancel Doc");
                data.Add("ReturnOrigin", "Return Origin");

                return data;
            }
        }

        public virtual Dictionary<string, string> last_status_list {
            get {   
                
                var data = new Dictionary<string, string>();
                data.Add("WaitReqMgrup", "Wait Req Mgrup");
                data.Add("WaitMPLCheck", "Wait MPL Check");
                data.Add("WaitCPDGM", "Wait CPD GM");
                data.Add("WaitPrepairing", "Wait Prepairing");
                data.Add("WaitAcknowledge", "Wait Acknowledge");
                data.Add("WaitReturn", "Wait Return");
                data.Add("Finish", "Finish");
                return data;
            }
        }
    }
}