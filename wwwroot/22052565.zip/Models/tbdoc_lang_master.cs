using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MPLContractIM.Models
{
    [Table("tbdoc_lang_master")]
    public class tbdoc_lang_master
    {
        [Key]
        public int id { get; set; }
        [MaxLength(50)]
        public string doc_lang { get; set; }
        [MaxLength(250)]
        public string input_name { get; set; }
        public DateTime input_date { get; set; }
        public DateTime input_datetime { get; set; }
        public DateTime last_update { get; set; }
        [MaxLength(250)]
        public string last_update_name { get; set; }
    }
}