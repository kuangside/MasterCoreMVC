using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MPLContractIM.Models
{
    [Table("tbdoc_gm")]
    public class tbdoc_gm
    {
        [Key]
        public int id { get; set; }
        [MaxLength(50)]
        public string dept_code { get; set; }
        [MaxLength(50)]
        public string email { get; set; }
    }
}