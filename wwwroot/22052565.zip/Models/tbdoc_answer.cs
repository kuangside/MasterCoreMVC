using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MPLContractIM.Models
{
    [Table("tbdoc_answer")]
    public class tbdoc_answer
    {
        [Key]
        public int id { get; set; }
        public int app_no_ref { get; set; }
        [MaxLength(50)]
        public string status_confirm { get; set; }
        [MaxLength(500)]
        public string company_approve { get; set; }
        [MaxLength(50)]
        public string input_name { get; set; }
        public DateTime input_date { get; set; }
    }
}