using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MPLContractIM.Models
{
    [Table("tbdoc_master")]
    public class tbdoc_master
    {
        [Key]
        public int id { get; set; }
        public string doc_no { get; }
        [MaxLength(50)]
        public string doc_lang { get; set; }
        [MaxLength(10)]
        public string doc_type { get; set; }
        [MaxLength(50)]
        public string doc_dep { get; set; }
        [MaxLength(10)]
        public string doc_fulldep { get; set; }
        [MaxLength(10)]
        public string doc_dep_code { get; set; }
        [MaxLength(15)]
        public string doc_div { get; set; }
        [MaxLength(50)]
        public string doc_div_code { get; set; }
        [MaxLength(4)]
        public string doc_year { get; set; }
        [MaxLength(500)]
        public string doc_name { get; set; }
        [MaxLength(500)]
        public string doc_contract { get; set; }
        public int doc_run { get; set; }
        [MaxLength(5)]
        public string doc_run_char { get; set; }
        [MaxLength(50)]
        public string doc_status { get; set; }
        public DateTime doc_input_date { get; set;}
        public DateTime doc_input_datetime { get; set;}
        [MaxLength(250)]
        public string doc_input_name { get; set; }
        public DateTime last_update { get; set;}
        [MaxLength(250)]
        public string last_update_name { get; set; }
        public DateTime cancel_datetime { get; set; }
        [MaxLength(50)]
        public string cancel_name { get; set; }
        public DateTime doc_expire_datetime { get; set; }
        [MaxLength(50)]
        public string doc_expire_name { get; set; }
    }
}