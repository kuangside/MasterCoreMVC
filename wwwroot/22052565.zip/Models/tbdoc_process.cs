using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MPLContractIM.Models
{
    [Table("tbdoc_process")]
    public class tbdoc_process
    {
        [Key]
        public int App_No { get; set; }
        public DateTime? App_Date { get; set; }
        [MaxLength(10)]
        public string App_Emp { get; set; }
        [MaxLength(200)]
        public string App_name { get; set; }
        [MaxLength(50)]
        public string App_Div { get; set; }
        [MaxLength(50)]
        public string App_Dept { get; set; }
        [MaxLength(50)]
        public string App_Position { get; set; }
        [MaxLength(20)]
        public string App_Ext { get; set; }
        [MaxLength(50)]
        public string App_Email { get; set; }
        [MaxLength(50)]
        public string Depos_type { get; set; }
        [MaxLength(30)]
        public string Depos_AttSN { get; set; }
        [MaxLength(50)]
        public string Doc_type { get; set; }
        [MaxLength(10)]
        public string Doc_copy { get; set; }
        [MaxLength(10)]
        public string Doc_Language { get; set; }
        [MaxLength(10)]
        public string Language_Trans { get; set; }
        [MaxLength(200)]
        public string cont_name { get; set; }
        [MaxLength(200)]
        public string cont_party { get; set; }
        [MaxLength(200)]
        public string cont_summary { get; set; }
        [MaxLength(150)]
        public string cont_category { get; set; }
        [MaxLength(10)]
        public string cont_renew { get; set; }
        [MaxLength(30)]
        public string cont_referSN { get; set; }
        [MaxLength(20)]
        public string cont_amount { get; set; }
        [MaxLength(20)]
        public string cont_page { get; set; }
        [MaxLength(5)]
        public string renewal { get; set; }
        [MaxLength(6)]
        public string renewal_item { get; set; }
        [MaxLength(5)]
        public string terminate { get; set; }
        [MaxLength(6)]
        public string terminate_item { get; set; }
        public DateTime? create_date { get; set; }
        public DateTime? effective_date { get; set; }
        public DateTime? end_date { get; set; }
        public DateTime? renew_date { get; set; }
        public DateTime? newend_date { get; set; }
        [MaxLength(3)]
        public string Lowyer_check { get; set; }
        [MaxLength(100)]
        public string Lowyer_reason { get; set; }
        [MaxLength(200)]
        public string Lowyer_other { get; set; }
        [MaxLength(500)]
        public string comment_req { get; set; }
        public DateTime? MTP_next_date { get; set; }
        [MaxLength(500)]
        public string MTP_note { get; set; }
        [MaxLength(200)]
        public string Attach_file { get; set; }
        [MaxLength(10)]
        public string App_req { get; set; }
        [MaxLength(10)]
        public string apprv_req { get; set; }
        public DateTime? apprv_req_date { get; set; }
        [MaxLength(500)]
        public string apprv_req_note { get; set; }
        [MaxLength(10)]
        public string apprv_mtp { get; set; }
        public DateTime? apprv_mtp_date { get; set; }
        [MaxLength(10)]
        public string apprv_mtpGM { get; set; }
        public DateTime? apprv_mtpGM_date { get; set; }
        [MaxLength(10)]
        public string apprv_prepare { get; set; }
        public DateTime? apprv_prepare_date { get; set; }
        [MaxLength(10)]
        public string apprv_finished { get; set; }
        public DateTime? apprv_finished_date { get; set; }
        [MaxLength(10)]
        public string reject_user { get; set; }
        public DateTime? reject_date { get; set; }
        [MaxLength(500)]
        public string reject_note { get; set; }
        [MaxLength(20)]
        public string process_status { get; set; }
        [MaxLength(20)]
        public string process_class { get; set; }
        [MaxLength(50)]
        public string contract_status { get; set; }
        public DateTime? up_expire_time { get; set; }
        [MaxLength(50)]
        public string contract_color { get; set; }
        [MaxLength(250)]
        public string location { get; set; }
        [MaxLength(50)]
        public string ack_status { get; set; }
        public DateTime? ack_datetime { get; set; }
        [MaxLength(50)]
        public string ack_name { get; set; }


        public virtual List<string> Depos_type_List{
            get {
                return new List<string>(){
                    "Main", "Attach"
                };
            }
        }
    }
}