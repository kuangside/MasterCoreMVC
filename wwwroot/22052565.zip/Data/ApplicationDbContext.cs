using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MPLContractIM.Models;

namespace MPLContractIM.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
        
        public DbSet<AppUser> AppUser { get; set; }
        public DbSet<tbdoc_answer> tbdoc_answer { get; set; }
        public DbSet<tbdoc_contact_master> tbdoc_contact_master { get; set; }
        public DbSet<tbdoc_gm> tbdoc_gm { get; set; }
        public DbSet<tbdoc_lang_master> tbdoc_lang_master { get; set; }
        public DbSet<tbdoc_master> tbdoc_master { get; set; }
        public DbSet<tbdoc_process> tbdoc_process { get; set; }
        public DbSet<tboth_request> tboth_request { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.Entity<AppUser>().HasData(new AppUser {
                id = "016623",
                empno = "016623",
                password  = "016623",
                fullname  = "Preedee P.",
                email  = "preedee@mail.connon",
                ext  = "1",
                dep  = "CPD",
                div  = "ICD",
                position  = "Sr.Programmer",
                name  = "016623",
                status  = "active",
                roles  = "Admin",
                create_date  = DateTime.Now,
                create_by  = "016623",
                update_date  = DateTime.Now,
                update_by  = "016623"
            });

            builder.Entity<tboth_request>()
                .HasOne(e=>e.tbdoc_process)
                .WithMany()
                .HasForeignKey(e=>e.mas_id);
        }
    }
}