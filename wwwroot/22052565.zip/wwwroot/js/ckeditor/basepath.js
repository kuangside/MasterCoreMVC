window.CKEDITOR_BASEPATH=document.querySelector("meta[name=homepage]").getAttribute("content").replace("/home","")+"/js/ckeditor/";
