using System.Net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using MPLContractIM.Data;
using MPLContractIM.Models;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using Newtonsoft.Json;

namespace MPLContractIM.Controllers
{
    [Authorize(Roles ="Admin")]
    public class UserController : Controller
    {
        private readonly ApplicationDbContext _context;

        public UserController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult> Index()
        {
            try
            {
                var data = await _context.AppUser.AsNoTracking().ToListAsync();
                return View(data);
            }
            catch (System.Exception)
            {
                TempData["error"] = "Error Code 500!";
                return View();
            }
            
        }

        [HttpGet]
        public ActionResult Create()
        {
            ViewData["formMode"] = "create";
            return View("Form", new AppUser());
        }

        [HttpPost]
        public async Task<ActionResult> Store(AppUser user)
        {
            try
            {
                var checkuser = await _context.AppUser.AsNoTracking().FirstOrDefaultAsync(u=>u.empno == user.empno);
                if(checkuser != null){
                    return Json(NotFound("User นี้มีข้อมูลอยู่แล้ว!"));
                }

                var data = new AppUser();
                data.id = user.empno;
                data.empno = user.empno;
                data.password = user.password;
                data.fullname = user.fullname;
                data.email = user.email;
                data.ext = user.ext;
                data.dep = user.dep;
                data.div = user.div;
                data.position = user.position;
                data.name = user.name;
                data.status = "active";
                data.roles = user.roles;
                data.create_date = DateTime.Now;
                data.create_by = User.FindFirst("id").Value;

                _context.AppUser.Add(data);
                await _context.SaveChangesAsync();

                // return Json(Ok(new { message= "เพิ่มข้อมูลสำเร็จ!", modalclose = "modal-create"}));
                TempData["success"] = "เพิ่มข้อมูลสำเร็จ!";
                return RedirectToAction("Index", "User");
            }
            catch (System.Exception)
            {                
                // return Json(BadRequest("เกิดข้อผิดพลาด"));
                TempData["error"] = "เกิดข้อผิดพลาด!";
                return RedirectToAction("Index", "User");
            }
            
        }

        [HttpGet]
        public async Task<ActionResult> Edit(string id)
        {
            try
            {
                var data = await _context.AppUser.AsNoTracking().FirstOrDefaultAsync(e=>e.id == id);
                if(data != null){
                    ViewData["formMode"] = "edit";
                    return View("Form",data);
                }
                
                return NotFound();
            }
            catch (System.Exception)
            {
                
                return BadRequest();
                throw;
            }
        }

        [HttpPost]
        public async Task<ActionResult> Update(AppUser user,string id)
        {
            try
            {
                var data = await _context.AppUser.FirstOrDefaultAsync(e=>e.id == id);
                if(data != null){
                    if(!string.IsNullOrEmpty(user.password)) data.password = user.password;
                    data.ext = user.ext;
                    data.roles = user.roles;
                    
                    await _context.SaveChangesAsync();

                    // return Json(Ok("Saved"));
                    TempData["success"] = "แก้ไขข้อมูลสำเร็จ!";
                    return RedirectToAction("Index", "User");
                }
                
                return NotFound();
            }
            catch (System.Exception)
            {
                
                // return BadRequest();
                TempData["error"] = "เกิดข้อผิดพลาด!";
                return RedirectToAction("Index", "User");
                throw;
            }
        }

        [HttpDelete]
        public async Task<ActionResult> Delete(AppUser user)
        {
            try
            {
                var data = await _context.AppUser.FirstAsync(u=>u.id == user.id && u.id != "016623");
                if(data != null){
                    _context.Remove(data);
                    await _context.SaveChangesAsync();
                    return Json(Ok("Deleted"));
                }
                // return Json(BadRequest(user));
                TempData["success"] = "ลบข้อมูลสำเร็จ!";
                return RedirectToAction("Index", "User");
            }
            catch (System.Exception)
            {
                // return Json(BadRequest("เกิดข้อผิดพลาด!"));
                TempData["error"] = "เกิดข้อผิดพลาด!";
                return RedirectToAction("Index", "User");
                throw;
            }
        }

        public async Task<IActionResult> ApiGetUser(string empno)
        {
            try
            {
                var data = await _context.AppUser.FirstOrDefaultAsync(a=>a.empno == empno);
                if(data != null){
                    return Json(Ok(data));
                }
                return Json(NotFound("NoData"));
            }
            catch (System.Exception)
            {
                return Json(BadRequest("NoData"));
                throw;
            }
        }

        [HttpGet]
        public async Task<ActionResult> getUserHR(string empno)
        {
            HttpClient client = new HttpClient();
            try
            {
                var values = new Dictionary<string, string>
                        {
                            { "command","SELECT * FROM ADMIN.V_EMP_DATA_ALL_CPT where EMP_NO = '"+empno+"'"}
                        };

                    var content = new FormUrlEncodedContent(values);

                    var response = await client.PostAsync("http://cptsvs531:1000/middleware/oracle/hrms", content);

                    var responseString = await response.Content.ReadAsStringAsync();
                    UserHrModel userhr = JsonConvert.DeserializeObject<UserHrModel>(responseString);
                    if(userhr != null){
                        var checkuser = await _context.AppUser.AsNoTracking().FirstOrDefaultAsync(u=>u.empno == userhr.data[0].EMP_NO);
                        if(checkuser != null){
                            return Json(NotFound("User นี้มีข้อมูลอยู่แล้ว!"));
                        }
                        return Json(Ok(userhr));
                    }
                    return Json(NotFound("ไม่พบข้อมูล!"));
            }
            catch (System.Exception)
            {                
                return Json(NotFound("ไม่พบข้อมูล!"));
            }
        }
    }
}