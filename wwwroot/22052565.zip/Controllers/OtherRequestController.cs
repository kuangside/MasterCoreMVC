using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MPLContractIM.Data;
using MPLContractIM.Models;

namespace MPLContractIM.Controllers
{
    public class OtherRequestController : Controller
    {
        private readonly ApplicationDbContext _context;

        public OtherRequestController(ApplicationDbContext context)
        {
            _context = context;
        }
        
        public IActionResult CreateMenu()
        {            
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Create(string type="UseOrgin")
        {
            ViewData["FormType"] = type;
            // if(type == "UseOrgin"){
            // }
            
            var docProcessList = await _context.tbdoc_process.ToListAsync();
            ViewData["docProcessList"] = docProcessList;

            return View("FormCreate", new tboth_request());
        }

        [HttpPost]
        public async Task<IActionResult> Store(tboth_request input)
        {
            var add = new tboth_request();
            add.mas_id = input.mas_id;
            add.run_no_id = input.run_no_id;
            add.run_topic = input.run_topic;
            add.run_no = input.run_no;
            add.doc_no = input.doc_no;
            add.type_request = input.type_request;
            add.pic_form = input.pic_form;
            add.pic_to = input.pic_to;
            add.date_form = input.date_form ?? null;
            add.date_to = input.date_to ?? null;
            add.last_status = input.last_status;
            add.input_user = input.input_user;
            add.input_date = input.input_date ?? null;
            add.req_user = input.req_user;
            add.req_name = input.req_name;
            add.req_div = input.req_div;
            add.req_dept = input.req_dept;
            add.req_position = input.req_position;
            add.req_ext = input.req_ext;
            add.req_email = input.req_email;
            add.mgr_status = input.mgr_status;
            add.mgr_name = input.mgr_name;
            add.mgr_date = input.mgr_date ?? null;
            add.mgr_reason = input.mgr_reason;
            add.chk_status = input.chk_status;
            add.chk_name = input.chk_name;
            add.chk_date = input.chk_date;
            add.chk_reason = input.chk_reason;
            add.cpd_status = input.cpd_status;
            add.cpd_name = input.cpd_name;
            add.cpd_date = input.cpd_date ?? null;
            add.cpd_reason = input.cpd_reason;
            add.pre_status = input.pre_status;
            add.pre_name = input.pre_name;
            add.pre_date = input.pre_date ?? null;
            add.pre_reason = input.pre_reason;
            add.akg_status = input.akg_status;
            add.akg_name = input.akg_name;
            add.akg_date = input.akg_date ?? null;
            add.akg_reason = input.akg_reason;
            add.return_status = input.return_status;
            add.return_name = input.return_name;
            add.return_date = input.return_date ?? null;
            add.return_reason = input.return_reason;
            _context.tboth_request.Add(add);
            await _context.SaveChangesAsync();
            
            TempData["success"] = "Add Other Request Success!";
            return RedirectToAction("CreateMenu", "OtherRequest");
        }

        [HttpGet]
        public async Task<ActionResult> OtherRequests(string status="")
        {
            return View();
        }

        [HttpGet]
        public async Task<ActionResult> TableOtherRequests()
        {
            var data = await _context.tboth_request.ToListAsync();
            return View(data);
        }

        [HttpGet]
        public async Task<ActionResult> FormApprove(string id="")
        {
            var data = await _context.tboth_request
                .Include(a=>a.tbdoc_process)
                .FirstOrDefaultAsync(a=>a.id.ToString() == id); 
            return View(data);
        }

        [HttpPost]
        public async Task<ActionResult> DoApproved(tboth_request input)
        {
            var data = await _context.tboth_request.FirstOrDefaultAsync(a=>a.id == input.id); 
            data.mgr_status = input.mgr_status;
            data.mgr_name = input.mgr_name;
            data.mgr_date = input.mgr_date ?? null;
            data.mgr_reason = input.mgr_reason;
            data.chk_status = input.chk_status;
            data.chk_name = input.chk_name;
            data.chk_date = input.chk_date;
            data.chk_reason = input.chk_reason;
            data.cpd_status = input.cpd_status;
            data.cpd_name = input.cpd_name;
            data.cpd_date = input.cpd_date ?? null;
            data.cpd_reason = input.cpd_reason;
            data.pre_status = input.pre_status;
            data.pre_name = input.pre_name;
            data.pre_date = input.pre_date ?? null;
            data.pre_reason = input.pre_reason;
            data.akg_status = input.akg_status;
            data.akg_name = input.akg_name;
            data.akg_date = input.akg_date ?? null;
            data.akg_reason = input.akg_reason;
            data.return_status = input.return_status;
            data.return_name = input.return_name;
            data.return_date = input.return_date ?? null;
            data.return_reason = input.return_reason;
            await _context.SaveChangesAsync();
            TempData["success"] = "Success";
            return RedirectToAction("OtherRequests","OtherRequest");
        }

        // [HttpPost]
        // public async Task<IActionResult> Deletex(string id="")
        // {
        //     try
        //     {
        //         var data = await _context.tboth_request.FirstOrDefaultAsync(e=>e.id.ToString() == id);
        //         if(data != null){
        //             ViewData["data"] = data;
        //             return RedirectToAction("CreateMenu", "OtherRequest");
        //         }
        //     }
        //     catch (System.Exception)
        //     {
        //         return RedirectToAction("CreateMenu", "OtherRequest");
        //         throw;
        //     }
        // }
        
    }
}