using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MPLContractIM.Data;
using MPLContractIM.Models;
using MPLContractIM.Helpers;

namespace MPLContractIM.Controllers
{
    public class DocProcessController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DocProcessController(ApplicationDbContext context)
        {
            _context = context;
        }
        
        public IActionResult Index()
        {            
            return View();
        }

        [HttpGet]
        public IActionResult Create(string type="")
        {
            ViewData["formType"] = type!="" ? type : "Main" ;
            return View("FormCreate", new tbdoc_process());
        }

        [HttpPost]
        public async Task<IActionResult> Store(tbdoc_process input)
        {
            var add = new tbdoc_process();
            // add.App_No = input.App_No;
            add.App_Date = Helper.ToDate(input.App_Date.ToString());
            add.App_Emp = input.App_Emp;
            add.App_name = input.App_name;
            add.App_Div = input.App_Div;
            add.App_Dept = input.App_Dept;
            add.App_Position = input.App_Position;
            add.App_Ext = input.App_Ext;
            add.App_Email = input.App_Email;
            add.Depos_type = input.Depos_type;
            add.Depos_AttSN = input.Depos_AttSN;
            add.Doc_type = input.Doc_type;
            add.Doc_copy = input.Doc_copy;
            add.Doc_Language = input.Doc_Language;
            add.Language_Trans = input.Language_Trans;
            add.cont_name = input.cont_name;
            add.cont_party = input.cont_party;
            add.cont_summary = input.cont_summary;
            add.cont_category = input.cont_category;
            add.cont_renew = input.cont_renew;
            add.cont_referSN = input.cont_referSN;
            add.cont_amount = input.cont_amount;
            add.cont_page = input.cont_page;
            add.renewal = input.renewal;
            add.renewal_item = input.renewal_item;
            add.terminate = input.terminate;
            add.terminate_item = input.terminate_item;
            add.create_date = Helper.ToDate(input.create_date.ToString());
            add.effective_date = input.effective_date;
            add.end_date = Helper.ToDate(input.end_date.ToString());
            add.renew_date = Helper.ToDate(input.renew_date.ToString());
            add.newend_date = Helper.ToDate(input.newend_date.ToString());
            add.Lowyer_check = input.Lowyer_check;
            add.Lowyer_reason = input.Lowyer_reason;
            add.Lowyer_other = input.Lowyer_other;
            add.comment_req = input.comment_req;
            add.MTP_next_date = Helper.ToDate(input.MTP_next_date.ToString());
            add.MTP_note = input.MTP_note;
            add.Attach_file = input.Attach_file;
            add.App_req = input.App_req;
            add.apprv_req = input.apprv_req;
            add.apprv_req_date = Helper.ToDate(input.apprv_req_date.ToString());
            add.apprv_req_note = input.apprv_req_note;
            _context.tbdoc_process.Add(add);
            await _context.SaveChangesAsync();

            TempData["success"] = "Add Data Success";
            return RedirectToAction("Index", "Home");
        }



        // [HttpPost]
        // public async Task<IActionResult> Deletex(string id="")
        // {
        //     try
        //     {
        //         var data = await _context.tboth_request.FirstOrDefaultAsync(e=>e.id.ToString() == id);
        //         if(data != null){
        //             ViewData["data"] = data;
        //             return RedirectToAction("CreateMenu", "OtherRequest");
        //         }
        //     }
        //     catch (System.Exception)
        //     {
        //         return RedirectToAction("CreateMenu", "OtherRequest");
        //         throw;
        //     }
        // }
        
    }
}