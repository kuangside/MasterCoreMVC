﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace MPLContractIM.Migrations
{
    public partial class InitialUser : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AppUser",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    empno = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    password = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    fullname = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    email = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    ext = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    dep = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    div = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    position = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    status = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    roles = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    create_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    create_by = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    update_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    update_by = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    delete_data = table.Column<DateTime>(type: "datetime2", nullable: true),
                    delete_by = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AppUser", x => x.id);
                });

            migrationBuilder.InsertData(
                table: "AppUser",
                columns: new[] { "id", "create_by", "create_date", "delete_by", "delete_data", "dep", "div", "email", "empno", "ext", "fullname", "name", "password", "position", "roles", "status", "update_by", "update_date" },
                values: new object[] { "1", "016623", new DateTime(2022, 5, 18, 17, 54, 19, 754, DateTimeKind.Local).AddTicks(8314), null, null, "CPD", "ICD", "preedee@mail.connon", "016623", "1", "Preedee P.", "016623", "016623", "Sr.Programmer", "Admin", "active", "016623", new DateTime(2022, 5, 18, 17, 54, 19, 755, DateTimeKind.Local).AddTicks(6154) });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AppUser");
        }
    }
}
