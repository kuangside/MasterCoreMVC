﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace MPLContractIM.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AppUser",
                keyColumn: "id",
                keyValue: "1");

            migrationBuilder.AlterColumn<string>(
                name: "roles",
                table: "AppUser",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(20)",
                oldMaxLength: 20,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "empno",
                table: "AppUser",
                type: "nvarchar(10)",
                maxLength: 10,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(10)",
                oldMaxLength: 10,
                oldNullable: true);

            migrationBuilder.CreateTable(
                name: "tbdoc_answer",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    app_no_ref = table.Column<int>(type: "int", nullable: false),
                    status_confirm = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    company_approve = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    input_name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    input_date = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbdoc_answer", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tbdoc_contact_master",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    contract_party = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    input_name = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    input_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    input_datetime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    last_update = table.Column<DateTime>(type: "datetime2", nullable: false),
                    last_update_name = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbdoc_contact_master", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tbdoc_gm",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    dept_code = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    email = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbdoc_gm", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tbdoc_lang_master",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    doc_lang = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    input_name = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    input_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    input_datetime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    last_update = table.Column<DateTime>(type: "datetime2", nullable: false),
                    last_update_name = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbdoc_lang_master", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tbdoc_master",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    doc_lang = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    doc_type = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    doc_dep = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    doc_fulldep = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    doc_dep_code = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    doc_div = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    doc_div_code = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    doc_year = table.Column<string>(type: "nvarchar(4)", maxLength: 4, nullable: true),
                    doc_name = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    doc_contract = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    doc_run = table.Column<int>(type: "int", nullable: false),
                    doc_run_char = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: true),
                    doc_status = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    doc_input_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    doc_input_datetime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    doc_input_name = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    last_update = table.Column<DateTime>(type: "datetime2", nullable: false),
                    last_update_name = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    cancel_datetime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    cancel_name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    doc_expire_datetime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    doc_expire_name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbdoc_master", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tbdoc_process",
                columns: table => new
                {
                    App_No = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    App_Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    App_Emp = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    App_name = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    App_Div = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    App_Dept = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    App_Position = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    App_Ext = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    App_Email = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Depos_type = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Depos_AttSN = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    Doc_type = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Doc_copy = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    Doc_Language = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    Language_Trans = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    cont_name = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    cont_party = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    cont_summary = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    cont_category = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    cont_renew = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    cont_referSN = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    cont_amount = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    cont_page = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    renewal = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: true),
                    renewal_item = table.Column<string>(type: "nvarchar(6)", maxLength: 6, nullable: true),
                    terminate = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: true),
                    terminate_item = table.Column<string>(type: "nvarchar(6)", maxLength: 6, nullable: true),
                    create_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    effective_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    end_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    renew_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    newend_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Lowyer_check = table.Column<string>(type: "nvarchar(3)", maxLength: 3, nullable: true),
                    Lowyer_reason = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Lowyer_other = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    comment_req = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    MTP_next_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    MTP_note = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Attach_file = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    App_req = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    apprv_req = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    apprv_req_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    apprv_req_note = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    apprv_mtp = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    apprv_mtp_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    apprv_mtpGM = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    apprv_mtpGM_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    apprv_prepare = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    apprv_prepare_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    apprv_finished = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    apprv_finished_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    reject_user = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    reject_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    reject_note = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    process_status = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    process_class = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    contract_status = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    up_expire_time = table.Column<DateTime>(type: "datetime2", nullable: false),
                    contract_color = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    location = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    ack_status = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ack_datetime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ack_name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbdoc_process", x => x.App_No);
                });

            migrationBuilder.CreateTable(
                name: "tboth_request",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    mas_id = table.Column<int>(type: "int", nullable: false),
                    run_no_id = table.Column<int>(type: "int", nullable: false),
                    run_topic = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    run_no = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    doc_no = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    type_request = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    pic_form = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    pic_to = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    date_form = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    date_to = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    last_status = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    input_user = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    input_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    req_user = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    req_name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    req_div = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    req_dept = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    req_position = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    req_ext = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    req_email = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    mgr_status = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    mgr_name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    mgr_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    mgr_reason = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    chk_status = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    chk_name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    chk_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    chk_reason = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    cpd_status = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    cpd_name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    cpd_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    cpd_reason = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    pre_status = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    pre_name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    pre_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    pre_reason = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    akg_status = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    akg_name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    akg_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    akg_reason = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    return_status = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    return_name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    return_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    return_reason = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    tbdoc_processApp_No = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tboth_request", x => x.id);
                    table.ForeignKey(
                        name: "FK_tboth_request_tbdoc_process_tbdoc_processApp_No",
                        column: x => x.tbdoc_processApp_No,
                        principalTable: "tbdoc_process",
                        principalColumn: "App_No",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "AppUser",
                columns: new[] { "id", "create_by", "create_date", "delete_by", "delete_data", "dep", "div", "email", "empno", "ext", "fullname", "name", "password", "position", "roles", "status", "update_by", "update_date" },
                values: new object[] { "016623", "016623", new DateTime(2022, 5, 20, 18, 15, 50, 872, DateTimeKind.Local).AddTicks(5864), null, null, "CPD", "ICD", "preedee@mail.connon", "016623", "1", "Preedee P.", "016623", "016623", "Sr.Programmer", "Admin", "active", "016623", new DateTime(2022, 5, 20, 18, 15, 50, 873, DateTimeKind.Local).AddTicks(3658) });

            migrationBuilder.CreateIndex(
                name: "IX_tboth_request_tbdoc_processApp_No",
                table: "tboth_request",
                column: "tbdoc_processApp_No");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tbdoc_answer");

            migrationBuilder.DropTable(
                name: "tbdoc_contact_master");

            migrationBuilder.DropTable(
                name: "tbdoc_gm");

            migrationBuilder.DropTable(
                name: "tbdoc_lang_master");

            migrationBuilder.DropTable(
                name: "tbdoc_master");

            migrationBuilder.DropTable(
                name: "tboth_request");

            migrationBuilder.DropTable(
                name: "tbdoc_process");

            migrationBuilder.DeleteData(
                table: "AppUser",
                keyColumn: "id",
                keyValue: "016623");

            migrationBuilder.AlterColumn<string>(
                name: "roles",
                table: "AppUser",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(20)",
                oldMaxLength: 20);

            migrationBuilder.AlterColumn<string>(
                name: "empno",
                table: "AppUser",
                type: "nvarchar(10)",
                maxLength: 10,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(10)",
                oldMaxLength: 10);

            migrationBuilder.InsertData(
                table: "AppUser",
                columns: new[] { "id", "create_by", "create_date", "delete_by", "delete_data", "dep", "div", "email", "empno", "ext", "fullname", "name", "password", "position", "roles", "status", "update_by", "update_date" },
                values: new object[] { "1", "016623", new DateTime(2022, 5, 18, 17, 54, 19, 754, DateTimeKind.Local).AddTicks(8314), null, null, "CPD", "ICD", "preedee@mail.connon", "016623", "1", "Preedee P.", "016623", "016623", "Sr.Programmer", "Admin", "active", "016623", new DateTime(2022, 5, 18, 17, 54, 19, 755, DateTimeKind.Local).AddTicks(6154) });
        }
    }
}
